<?php

class PaycoinGateway_ApiException extends PaycoinGateway_Exception
{
}
